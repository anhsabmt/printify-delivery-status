# Printify Delivery Status 1.0.0

## Installation
1. Upload the plugin ZIP in WordPress → Plugins → Add New → Upload Plugin, then activate.
2. Put the service account JSON outside the public web directory on the WordPress server. Do not include it in the ZIP. The Windows path on your computer is not the path on your hosting server.
3. Open WooCommerce → Printify Delivery and enter the absolute server path to the JSON.
4. Verify the spreadsheet ID and tab, save, then click Sync now.
5. Refresh after the background job finishes. Review candidate matches and manually approve multiple sources before grouping.

## Behavior
- Hourly background sync using Action Scheduler, with WP-Cron fallback.
- Shipping recipient name plus shipping phone (billing phone fallback).
- Case and whitespace normalization; US/CA leading 1 normalization. No fuzzy name matching.
- Ambiguous matches are not automatically assigned. Multiple sources require manual approval.
- Existing links persist by Shop ID + Printify Order ID, including when rows are sorted.
- No match is displayed until linked. Source statuses stay separate for multiple linked sources.
- Source checked time older than three hours is marked Stale.
- Last successful data is retained on Google failures or empty/invalid sheets.
- Does not change WooCommerce order status or write Google Sheet cells.
- HPOS and legacy order list supported; delivery column is appended to the existing columns.
- Deactivation removes plugin schedules; stored links and data remain.

## Validation before production
Test on staging with unique matches, returning customers with duplicate phone/name, US and international phones, split orders, manual relinking, stale data, Google permission failures, reordered sheet columns, and HPOS/legacy lists. Configure a real server cron if WP-Cron does not run reliably.

## Limits
This first release scans WooCommerce orders in pages of 100 during sync. Large stores may require batch jobs and a dedicated indexed matching table. Address matching is deferred. Status filter, bulk manual linking, and automated source completeness checks are not included. Runtime validation on a WordPress staging site is required.
